package com.pluralsight.conference.demo.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceApp {
	public static void main(String[] args) {
		SpringApplication.run(ConferenceApp.class, args);
	}

}
